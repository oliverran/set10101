# GenericDBProj
Generic Java application demonstrating a three layer architecture, MVC, database access and reflection (school project)
